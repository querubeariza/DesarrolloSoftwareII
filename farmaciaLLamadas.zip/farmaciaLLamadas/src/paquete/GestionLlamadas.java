package paquete;

import java.util.LinkedList;
import java.util.Queue;

public class GestionLlamadas {
    private Queue<Llamada> colaLlamadas = new LinkedList<>();

    public void agregarLlamada(String nombreCliente, String numeroTelefono) {
        Llamada nuevaLlamada = new Llamada(nombreCliente, numeroTelefono);
        colaLlamadas.offer(nuevaLlamada);
        System.out.println("Llamada agregada correctamente.");
    }

    public void atenderLlamada() {
        if (colaLlamadas.isEmpty()) {
            System.out.println("No hay llamadas pendientes.");
        } else {
            Llamada llamadaAtendida = (Llamada) colaLlamadas.poll();
            System.out.println("Llamada atendida:");
            System.out.println("Nombre del cliente: " + llamadaAtendida.getNombreCliente());
            System.out.println("Número de teléfono: " + llamadaAtendida.getNumeroTelefono());
        }
    }

    public void imprimirLlamadasPendientes() {
        if (colaLlamadas.isEmpty()) {
            System.out.println("No hay llamadas pendientes.");
        } else {
            System.out.println("Llamadas pendientes:");
            for (Llamada llamada : colaLlamadas) {
                System.out.println("Nombre del cliente: " + llamada.getNombreCliente());
                System.out.println("Número de teléfono: " + llamada.getNumeroTelefono());
                System.out.println();
            }
        }
    }
}
