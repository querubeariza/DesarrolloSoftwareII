package paquete;
import java.util.LinkedList;
import java.util.Queue;

public class Llamada {
    private String nombreCliente;
    private String numeroTelefono;

    public Llamada(String nombreCliente, String numeroTelefono) {
        this.nombreCliente = nombreCliente;
        this.numeroTelefono = numeroTelefono;
    }

    public String getNombreCliente() {
        return nombreCliente;
    }

    public String getNumeroTelefono() {
        return numeroTelefono;
    }
}

