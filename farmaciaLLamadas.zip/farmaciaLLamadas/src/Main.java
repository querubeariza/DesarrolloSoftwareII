import paquete.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {
    public static void main(String[] args) {
        GestionLlamadas gestionLlamadas = new GestionLlamadas();
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        int opcion = 0;
        String nombreCliente;
        String numeroTelefono;
        do {
            System.out.println("MENÚ");
            System.out.println("1. Agregar Llamada");
            System.out.println("2. Atender Llamada");
            System.out.println("3. Visualizar Llamadas Pendientes");
            System.out.println("4. Salir");
            System.out.print("Ingrese una opción: ");

            try {
                opcion = Integer.parseInt(reader.readLine());

                switch (opcion) {
                    case 1:
                        System.out.print("Ingrese el nombre del cliente: ");
                         nombreCliente = reader.readLine();
                        System.out.print("Ingrese el número de teléfono: ");
                         numeroTelefono = reader.readLine();
                        gestionLlamadas.agregarLlamada(nombreCliente, numeroTelefono);
                        break;
                    case 2:
                        gestionLlamadas.atenderLlamada();
                        break;
                    case 3:
                        gestionLlamadas.imprimirLlamadasPendientes();
                        break;
                    case 4:
                        System.out.println("Saliendo del programa...");
                        break;
                    default:
                        System.out.println("Opción inválida. Intente nuevamente.");
                }
            } catch (IOException e) {
                System.out.println("Error de entrada/salida: " + e.getMessage());
            } catch (NumberFormatException e) {
                System.out.println("Entrada inválida. Debe ingresar un número entero.");
            }

            System.out.println();
        } while (opcion != 4);
    }
}